package com.h96modern.launcher;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ApplicationInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ScrollView;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(8,13,24), teal = Color.rgb(32,230,210);
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private GradientDrawable shape(int color, int stroke) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(18));
        if (stroke != 0) d.setStroke(dp(1), stroke); return d;
    }
    private TextView label(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD)); return t;
    }
    @Override public void onCreate(Bundle b) { super.onCreate(b); getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg); build(); }
    private void build() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(28),dp(22),dp(28),dp(18)); root.setBackgroundColor(bg);
        TextView brand = label("H96  /  NEXUS", 18, teal); root.addView(brand);
        TextView clock = label(new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date()), 48, Color.WHITE); clock.setPadding(0,dp(12),0,0); root.addView(clock);
        TextView date = label(new SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(new Date()), 15, 0xff9EADBF); root.addView(date);
        TextView heading = label("TUS APLICACIONES", 13, teal); heading.setPadding(0,dp(28),0,dp(12)); root.addView(heading);
        ScrollView scroll = new ScrollView(this); LinearLayout grid = new LinearLayout(this); grid.setOrientation(LinearLayout.VERTICAL); scroll.addView(grid); root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        PackageManager pm = getPackageManager();
        Intent query = new Intent(Intent.ACTION_MAIN); query.addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
        List<android.content.pm.ResolveInfo> apps = pm.queryIntentActivities(query,0);
        if (apps.isEmpty()) { query.removeCategory(Intent.CATEGORY_LEANBACK_LAUNCHER); query.addCategory(Intent.CATEGORY_LAUNCHER); apps = pm.queryIntentActivities(query,0); }
        for (android.content.pm.ResolveInfo info : apps) {
            final String pkg = info.activityInfo.packageName;
            LinearLayout card = new LinearLayout(this); card.setGravity(Gravity.CENTER_VERTICAL); card.setPadding(dp(18),dp(14),dp(18),dp(14)); card.setBackground(shape(0xff121D2E,0xff1D5360));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,dp(66)); lp.bottomMargin=dp(10); grid.addView(card,lp);
            TextView icon = new TextView(this); icon.setText("◆"); icon.setTextSize(23); icon.setTextColor(teal); card.addView(icon);
            TextView name = label("   "+info.loadLabel(pm).toString(),18,Color.WHITE); card.addView(name,new LinearLayout.LayoutParams(0,-2,1));
            card.setFocusable(true); card.setClickable(true); card.setOnClickListener(v -> { Intent launch=pm.getLaunchIntentForPackage(pkg); if(launch!=null) startActivity(launch); });
            card.setOnFocusChangeListener((v,focus)->v.setBackground(shape(focus?0xff173444:0xff121D2E,focus?teal:0xff1D5360)));
        }
        TextView footer = label("NEXUS  •  Tu centro de entretenimiento",12,0xff718398); footer.setGravity(Gravity.CENTER); footer.setPadding(0,dp(12),0,0); root.addView(footer);
        setContentView(root);
    }
}
