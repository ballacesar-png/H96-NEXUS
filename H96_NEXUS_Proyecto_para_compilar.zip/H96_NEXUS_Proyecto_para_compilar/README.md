# H96 NEXUS

Launcher Android sencillo para TV Box, con fondo oscuro, acentos turquesa y accesos a aplicaciones instaladas.

## Compilar APK

El repositorio incluye GitHub Actions. Sube el contenido del proyecto conservando las carpetas, especialmente `.github/workflows/android.yml`. En GitHub abre **Actions**, selecciona **Build H96 NEXUS APK** y pulsa **Run workflow**. Al finalizar, descarga el artefacto `H96-NEXUS-debug`.

El APK es una compilación de depuración. Instálalo primero como aplicación y conserva el launcher original hasta comprobar compatibilidad con tu firmware.
